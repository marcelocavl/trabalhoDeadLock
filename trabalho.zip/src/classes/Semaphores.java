package classes;

import java.util.concurrent.Semaphore;

public class Semaphores{

	public static Semaphore mutex=new Semaphore(1);
}
